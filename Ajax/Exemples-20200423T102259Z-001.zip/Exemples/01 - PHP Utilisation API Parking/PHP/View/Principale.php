﻿<!-- Cette page est le contenu de la page principale du site; Elle présente la liste des parkings. -->

<div id="divSousTitre">
	<h3>Selectionner un parking</h3>
</div>
<div id="divContenu">
	<div class="ligne titreLigne">
		<div class="ville">Ville</div>
		<div class="libelle">Nom du Parking</div>
		<div class="dispo">Etat</div>
	</div>
	<div class="espaceHorizon"></div>
</div>