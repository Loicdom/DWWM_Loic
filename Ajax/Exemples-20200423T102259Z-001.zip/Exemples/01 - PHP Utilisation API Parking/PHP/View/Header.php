
<body>
	<div id="page">
		<div id="entete">
			<div id="titre">
				<div id="logo">
			 	<img src="Images/logo.png" />
				</div>

				<div id="titre_page">
                  Parking de Lille
                </div>
            </div>
		</div>
        <div id="contenu">
