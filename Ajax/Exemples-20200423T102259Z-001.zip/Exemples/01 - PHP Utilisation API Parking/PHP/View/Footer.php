<!--  Referme les balises ouvertes dans le Header -->

</div>
<div class="piedDePage">
<div class="espaceHorizon"></div>
<div class="espaceHorizon"></div>
<div class="espaceHorizon"></div>
Réalisé par MP<br>

</div>
</div>
</div>
<script src="JS/ajax.js"></script>
</body>

</html>